# Sharon-WhatsApp-Bot-ChatGPT
Simple Example WhatsApp Bot with NodeJS and Baileys Library
Connect to ChatGPT
