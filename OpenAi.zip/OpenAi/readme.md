## ChatGPT-WhatsApp

ChatGPT dapat digunakan untuk berbagai tujuan, termasuk bahasa pemrograman, bahasa mesin, matematika, sistem pakar, dan lainnya.

## Instalation

```javascript
git clone https://github.com/theazran/chatgpt-whatsapp.git
cd chatgpt-whatsapp
npm install
npm start
```

## Add API Key

Login atau Daftar dan ambil API Key kamu [di sini](https://beta.openai.com/account/api-keys).
Untuk menggunakan bot ini kamu harus mengganti API Key pada [baris ini](https://github.com/theazran/chatgpt-whatsapp/blob/master/.env).

## Demo

Gunakan dengan bijak [ChatGPT WhatsApp](https://s.id/chatGPT)

## Creator

- `Instagram` [@theazran\_](https://instagram.com/theazran_)
- `Facebook` [M ASRAN](https://fb.com/theazran)
